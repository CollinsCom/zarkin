<?php include_once('funciones.php'); // Incluimos nuestro archivo de funciones para tener acceso a todos los métodos que se encuentran en él. ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
<head>
	<title>Ejemplo combos dependientes</title>
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script> <!-- Enlace a la librería de jquery -->
    <script type="text/javascript" src="js/procesar.js"></script> <!-- Archivo de javascript que crearás para introducir el código que hace que funcionen los combos -->
</head>
<body>
	<?php formulario(); //Funcion que contiene a nuestro formulario. ?>
</body>
</html>